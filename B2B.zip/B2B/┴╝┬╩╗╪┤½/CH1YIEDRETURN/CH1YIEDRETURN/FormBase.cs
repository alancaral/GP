﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using Newtonsoft.Json;
using System.Net.Http;
using System.Data;
using Oracle.DataAccess.Client;
using Amib.Threading;
using Newtonsoft.Json.Linq;
using System.Threading;
using System.Configuration;

namespace CH1YIEDRETURN
{
    public partial class FormBase : Form
    {
        OracleHelpMes oraProdEnv;
        private static SmartThreadPool smartThreadPool;
        string v_Hour = "";
        string v_Minute = "";
        System.Timers.Timer timer = new System.Timers.Timer();

        public FormBase()
        {
            InitializeComponent();
        }

        private void FormBase_Load(object sender, EventArgs e)
        {
            this.textBox1.ShortcutsEnabled = false;
            this.checkTime.Enabled = false;
            this.btnSend.Enabled = false;
            timer.Enabled = true;
            timer.Interval = 60000*5;//执行间隔时间,单位为毫秒  
            timer.Start();
            timer.Elapsed += new System.Timers.ElapsedEventHandler(Timer1_Elapsed);
        }

        private void Timer1_Elapsed(object sender, System.Timers.ElapsedEventArgs e)
        {
            try
            {
                timer.Enabled = false;

                string date = e.SignalTime.Date.ToShortDateString();

                SendMessage(e.SignalTime);

                timer.Enabled = true;
            }
            catch { }
            finally
            {
                timer.Enabled = true;
            }

        }

        private void btnSend_Click(object sender, EventArgs e)
        {
            try
            {
                if ((char)MessageBox.Show("是否要手动发送数据,请确认!", "SendMessageToCustom", MessageBoxButtons.YesNo, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button2) == (char)DialogResult.No)
                {
                    return;
                }
                SendMessage(this.inputTime.Value);
            }
            catch { }
            finally
            {
                this.btnSend.Enabled = true;
            }
        }

        private DataSet GetCustomQueryDetail1(OracleHelpMes ora)
        {
            string ssql = @"select d.customernumber,
                                   d.suppliername,
                                   d.factoryname,
                                   d.customermodel,
                                   d.lotnumber,
                                   d.serialnumber,
                                   d.productnumber,
                                   d.line,
                                   d.qctime,
                                   d.teststation,
                                   d.testitemname,
                                   d.testsubitemname,
                                   d.controlupperlimit,
                                   d.controllowerlimit,
                                   d.testunit,
                                   d.testresult,
                                   d.rawdataid,
                                   d.testcharresult,
                                   d.isverification,
                                   d.remark,
                                   d.timekey,
                                   d.issend
                              from ch1_yield_return_true d
                             where 1=1
                               and d.issend = 'N' ";

            OracleCommand cmd = new OracleCommand();
            cmd.CommandText = ssql;

            //cmd.Parameters.Add(new OracleParameter("starttime", starttime));
            //cmd.Parameters.Add(new OracleParameter("endtime", endtime));

            DataSet ds = ora.GetDataSet(cmd);

            return ds;
        }

        public string PostAsync(CustomSendHW csHW, string strURL)
        {
            string retStr = "";
            try
            {
                var body = new FormUrlEncodedContent(new Dictionary<string, string>
                {
                    { "serviceInterfaceCode",csHW.serviceInterfaceCode},
                    { "fromInterfaceCode", csHW.fromInterfaceCode},
                    { "toInterfaceCode", csHW.toInterfaceCode},
                    { "ouZone", csHW.ouZone},
                    { "factoryName", csHW.factoryName},
                    { "uuid", csHW.uuid},
                    { "requestTime", csHW.requestTime},
                    { "data", csHW.data},
                });

                var httpClient = new HttpClient();

                string response = "";
                for (int i = 0; i < 20; i++)
                {
                    var responseVar = httpClient.PostAsync(strURL, body).Result;
                    response = responseVar.Content.ReadAsStringAsync().Result;
                    JObject resposeJson = JObject.Parse(response);
                    retStr = resposeJson["successMsg"].ToString();
                    if (string.Equals(retStr, "success")) break;
                    else insertErrorMessage(response, csHW.data);
                    Thread.Sleep(500);
                }
            }
            catch { }

            return retStr;

        }

        private void checkTime_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                if (this.checkTime.Checked)
                {
                    this.dTPick.Enabled = false;
                    v_Hour = string.Format("{0:HH}", this.dTPick);
                    v_Minute = string.Format("{0:mm}", this.dTPick);
                }
                else
                {
                    this.dTPick.Enabled = true;
                    v_Hour = "";
                    v_Minute = "";
                }
            }
            catch { }
        }

        private void FormBase_SizeChanged(object sender, EventArgs e)
        {
            try
            {
                //判断是否选择的是最小化按钮
                if (WindowState == FormWindowState.Minimized)
                {
                    //隐藏任务栏区图标
                    this.ShowInTaskbar = false;
                    //图标显示在托盘区
                    notifyIcon1.Visible = true;
                }
            }
            catch { }
        }

        private void notifyIcon1_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            try
            {
                if (WindowState == FormWindowState.Minimized)
                {
                    //还原窗体显示    
                    WindowState = FormWindowState.Normal;
                    //激活窗体并给予它焦点
                    this.Activate();
                    //任务栏区显示图标
                    this.ShowInTaskbar = true;
                    //托盘区图标隐藏
                    notifyIcon1.Visible = false;
                }
                else if (WindowState == FormWindowState.Normal)
                {
                    MessageBox.Show("sadiu");
                }
            }
            catch { }
        }

        private void FormBase_FormClosing(object sender, FormClosingEventArgs e)
        {
            try
            {
                char flag = (char)MessageBox.Show("关闭该界面,自动传输功能将失效,请确认!", "SendMessageToCustom", MessageBoxButtons.YesNo, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button2);
                if (flag == (char)DialogResult.No)
                {
                    e.Cancel = true;
                }
            }
            catch { }
        }

        private void SendMessage(DateTime nowTime)
        {
            try
            {
                smartThreadPool = new SmartThreadPool(5000, 10, 1);

                string dbStr = ConfigurationManager.AppSettings["PROD_EDB"].ToString();

                string dbConnectStr = ConfigurationManager.ConnectionStrings[dbStr].ConnectionString.ToString();

                oraProdEnv = new OracleHelpMes();
                oraProdEnv.baseStr = dbConnectStr;

                //string strURL_TST = "http://10.100.8.234:33001/b2b/mes/huawei/tplcdQCVoList";  //测试接口
                string strURL_PROD = "http://172.18.2.33:33001/b2b/mes/huawei/tplcdQCVoList";  //正式接口

                DataSet getCustomHWList = GetCustomQueryDetail1(oraProdEnv);

                if (getCustomHWList.Tables[0].Rows.Count > 0)
                {
                    List<CustomHW> lstCusHW = new List<CustomHW>();
                    int setCount = 0;
                    insertErrorMessage("start", "sendMessage");
                    for (int i = 0; i < getCustomHWList.Tables[0].Rows.Count; i++)
                    {
                        //decimal controlupperlimit = 0;
                        //decimal controllowerlimit = 0;
                        //if (!string.IsNullOrEmpty(getCustomHWList.Tables[0].Rows[i]["controlupperlimit"].ToString()))
                        //{
                        //    controlupperlimit = Convert.ToDecimal(getCustomHWList.Tables[0].Rows[i]["controlupperlimit"].ToString());
                        //}
                        //if (!string.IsNullOrEmpty(getCustomHWList.Tables[0].Rows[i]["controllowerlimit"].ToString()))
                        //{
                        //    controllowerlimit = Convert.ToDecimal(getCustomHWList.Tables[0].Rows[i]["controllowerlimit"].ToString());
                        //}

                        //设置参数
                        CustomHW chw = new CustomHW();
                        chw.customerNumber = getStr(getCustomHWList.Tables[0].Rows[i]["customernumber"]);
                        chw.supplierName = getStr(getCustomHWList.Tables[0].Rows[i]["suppliername"]);
                        chw.factoryName = getStr(getCustomHWList.Tables[0].Rows[i]["factoryname"]);
                        chw.customerModel = getStr(getCustomHWList.Tables[0].Rows[i]["customermodel"]);
                        chw.lotNumber = "";
                        chw.serialNumber = getStr(getCustomHWList.Tables[0].Rows[i]["serialnumber"]) == "" ? "/" : getStr(getCustomHWList.Tables[0].Rows[i]["serialnumber"]);
                        chw.productNumber = getStr(getCustomHWList.Tables[0].Rows[i]["productnumber"]);
                        chw.line = getStr(getCustomHWList.Tables[0].Rows[i]["line"]);
                        chw.qcTime = ConvertDataTimeToLong(Convert.ToDateTime(getCustomHWList.Tables[0].Rows[i]["qctime"].ToString()));
                        chw.testStation = getStr(getCustomHWList.Tables[0].Rows[i]["teststation"]);
                        chw.testItemName = getStr(getCustomHWList.Tables[0].Rows[i]["testitemname"]);
                        chw.testSubItemName = getStr(getCustomHWList.Tables[0].Rows[i]["testsubitemname"]);
                        chw.controlUpperLimit = getStr(getCustomHWList.Tables[0].Rows[i]["controlupperlimit"]);
                        chw.controlLowerLimit = getStr(getCustomHWList.Tables[0].Rows[i]["controllowerlimit"]);
                        chw.testUnit = getStr(getCustomHWList.Tables[0].Rows[i]["testunit"]);
                        chw.testResult = getStr(getCustomHWList.Tables[0].Rows[i]["testresult"]);
                        chw.rawDataID = getStr(getCustomHWList.Tables[0].Rows[i]["rawdataid"]);
                        chw.testCharResult = getStr(getCustomHWList.Tables[0].Rows[i]["testcharresult"]).ToUpper();
                        chw.isVerification = "";
                        chw.remark = "";

                        lstCusHW.Add(chw);

                        setCount++;
                        updateSendInfo(getStr(getCustomHWList.Tables[0].Rows[i]["timekey"]));

                        if (setCount == 1)
                        {
                            string jsonPara_Temp = JsonConvert.SerializeObject(lstCusHW);

                            CustomSendHW csHW_Temp = new CustomSendHW();
                            csHW_Temp.serviceInterfaceCode = "B2BHW0100";
                            csHW_Temp.fromInterfaceCode = "B2BTMXMMES0100";
                            csHW_Temp.toInterfaceCode = "B2BHWH0100";
                            csHW_Temp.ouZone = "OU_TMXM";
                            csHW_Temp.factoryName = "XM G6";
                            csHW_Temp.uuid = "1617355496bb588e353e80147eea5f45";
                            csHW_Temp.requestTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
                            csHW_Temp.data = jsonPara_Temp;

                            Amib.Threading.IWorkItemResult<string> threadRet = smartThreadPool.QueueWorkItem(new Amib.Threading.Func<CustomSendHW, string, string>(PostAsync),
                                csHW_Temp, strURL_PROD);

                            setCount = 0;
                            lstCusHW.Clear();
                        }
                    }

                    string jsonParas = JsonConvert.SerializeObject(lstCusHW);

                    CustomSendHW csHW = new CustomSendHW();
                    csHW.serviceInterfaceCode = "B2BHW0100";
                    csHW.fromInterfaceCode = "B2BTMXMMES0100";
                    csHW.toInterfaceCode = "B2BHWH0100";
                    csHW.ouZone = "OU_TMXM";
                    csHW.factoryName = "XM G6";
                    csHW.uuid = "1617355496bb588e353e80147eea5f45";
                    csHW.requestTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
                    csHW.data = jsonParas;

                    Amib.Threading.IWorkItemResult<string> threadRet1 = smartThreadPool.QueueWorkItem(new Amib.Threading.Func<CustomSendHW, string, string>(PostAsync),
                                csHW, strURL_PROD);

                    insertErrorMessage("end", "sendMessage");
                }

                smartThreadPool.Start();
                smartThreadPool.WaitForIdle();

            }
            catch (Exception e)
            {
                this.txtReturnData.AppendText("发送失败!"); 
            }
        }

        private void insertErrorMessage(string response, string data)
        {
            string ssql = @"insert into ct_returninfo_hw_err(timekey,errormessage,message)
                              values(:timekey,:errormessage,:message)";

            OracleCommand cmd = new OracleCommand();
            cmd.CommandText = ssql;

            cmd.Parameters.Add(new OracleParameter("timekey", string.Format("{0:yyyyMMddHHmmss}", System.DateTime.Now)));
            cmd.Parameters.Add(new OracleParameter("errormessage", response));
            cmd.Parameters.Add(new OracleParameter("message", data));

            string prod = ConfigurationManager.AppSettings["PROD_EDB"].ToString();
            string prodConnectStr = ConfigurationManager.ConnectionStrings[prod].ConnectionString.ToString();

            oraProdEnv = new OracleHelpMes();
            oraProdEnv.baseStr = prodConnectStr;

            oraProdEnv.QueryCmd(cmd);

        }

        private void btnTest_Click(object sender, EventArgs e)
        {
            try
            {

            }
            catch { }
        }

        public long ConvertDataTimeToLong(DateTime dt)
        {
            DateTime dtStart = TimeZone.CurrentTimeZone.ToLocalTime(new DateTime(1970, 1, 1));
            TimeSpan toNow = dt.Subtract(dtStart);
            long timeStamp = toNow.Ticks;
            timeStamp = long.Parse(timeStamp.ToString().Substring(0, timeStamp.ToString().Length - 4));
            return timeStamp;
        }

        public string getStr(object str)
        {
            string retStr = "";
            retStr = str == null ? "" : str.ToString();
            return retStr;
        }

        public void updateSendInfo(string timekey)
        {
            try
            {
                string ssql = @"update ch1_yield_return_true
                                   set issend = 'Y'
                                 where timekey = :timekey ";

                OracleCommand cmd = new OracleCommand();
                cmd.CommandText = ssql;
                cmd.Parameters.Add(new OracleParameter("timekey", timekey));

                string prod = ConfigurationManager.AppSettings["PROD_EDB"].ToString();
                string prodConnectStr = ConfigurationManager.ConnectionStrings[prod].ConnectionString.ToString();

                oraProdEnv = new OracleHelpMes();
                oraProdEnv.baseStr = prodConnectStr;

                oraProdEnv.QueryCmd(cmd);
            }
            catch { }
        }

    }
}