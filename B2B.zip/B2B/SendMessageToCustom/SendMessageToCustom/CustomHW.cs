﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SendMessageToCustom
{
    public class CustomHW
    {
        
        public string customerNumber { get; set; }

        public string supplierName { get; set; }

        public string factoryName { get; set; }

        public string customerModel { get; set; }

        public string lotNumber { get; set; }

        public string serialNumber { get; set; }

        public string productNumber{ get; set; }

        public string line{ get; set; }

        public long qcTime { get; set; }

        public string testStation { get; set; }

        public string testItemName { get; set; }

        public string testSubItemName { get; set; }

        public string controlUpperLimit { get; set; }

        public string controlLowerLimit { get; set; }

        public string testUnit { get; set; }

        public string testResult { get; set; }

        public string rawDataID { get; set; }

        public string testCharResult { get; set; }

        public string isVerification { get; set; }

        public string remark { get; set; }

    }
}
