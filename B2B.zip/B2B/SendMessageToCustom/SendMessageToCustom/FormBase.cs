﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using Newtonsoft.Json;
using System.Configuration;
using System.Net.Http;
using System.Data;
using Oracle.DataAccess.Client;
using System.ComponentModel;
using Amib.Threading;
using Newtonsoft.Json.Linq;
using System.Threading;

namespace SendMessageToCustom
{
    public partial class FormBase : Form
    {
        OracleHelpMes oraProdEnv;
        private static SmartThreadPool smartThreadPool;
        string v_Hour = "";
        string v_Minute = "";
        System.Timers.Timer timer = new System.Timers.Timer();

        public FormBase()
        {
            InitializeComponent();
        }

        private void FormBase_Load(object sender, EventArgs e)
        {
            this.textBox1.ShortcutsEnabled = false;
            this.checkTime.Enabled = false;
            //this.btnSend.Enabled = false;
            timer.Enabled = true;
            timer.Interval = 60000;//执行间隔时间,单位为毫秒  
            timer.Start();
            timer.Elapsed += new System.Timers.ElapsedEventHandler(Timer1_Elapsed); 
        }

        private void Timer1_Elapsed(object sender, System.Timers.ElapsedEventArgs e)  
        {
            try
            {
                timer.Enabled = false;

                string date = e.SignalTime.Date.ToShortDateString();

                // 得到 hour minute second 如果等于某个值就开始执行某个程序。  
                string intHour = e.SignalTime.Hour.ToString();
                string intMinute = e.SignalTime.Minute.ToString();

                // 定制时间;比如在09:30:00的时候执行统计良率  
                string iHour = "16";
                string iMinute = "56";

                // 定制时间 10:30:00的时候执行是否发送
                string sHour = "16";
                string sMinute = "58";

                // 设置每天定时开始执行程序  
                if (intHour == iHour && intMinute == iMinute)
                {
                    //计算良率
                    calculateYield(e.SignalTime);
                }
                else if (intHour == sHour && intMinute == sMinute)
                {
                    //良率OK则发送数据
                    if (this.chkAutoSend(e.SignalTime))
                    {
                        insertErrorMessage("start","sendMessage");
                        SendMessage(e.SignalTime);
                        insertErrorMessage("end", "sendMessage");
                    }
                }

                //判断是否已更新良率问题，手动发送
                if (Convert.ToInt32(intMinute) % 10 == 0)
                {
                    for (int i = 0; i < 7; i++)
                    {
                        if (this.chkSendFromMes(e.SignalTime.AddDays(-i)))
                        {
                            SendMessage(e.SignalTime.AddDays(-i));
                        }
                    }
                }

                timer.Enabled = true;
            }
            catch { }
            finally
            {
                timer.Enabled = true;
            }

        }

        private void btnSend_Click(object sender, EventArgs e)
        {
            try
            {
                if ((char)MessageBox.Show("是否要手动发送数据,请确认!", "SendMessageToCustom", MessageBoxButtons.YesNo, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button2) == (char)DialogResult.No)
                {
                    return;
                }
                SendMessage(this.inputTime.Value);
            }
            catch { }
            finally
            {
                this.btnSend.Enabled = true;
            }
        }

        private DataSet GetCustomQueryDetail(OracleHelpMes ora, string starttime, string endtime)
        {
            string ssql = @"select h.customernumber,
                                   h.suppliername,
                                   h.factoryname,
                                   h.customermodel,
                                   '' as lotnumber,
                                   d.serialnumber,
                                   d.productnumber,
                                   d.line,
                                   d.qctime,
                                   h.teststation,
                                   h.testitemName,
                                   decode(h.testitemName,
                                          'Bonding 时间',
                                          'Bonding Time #1',
                                          'Bonding 温度',
                                          'Bonding Backup Stage Temperature #1',
                                          'Bonding 压力',
                                          'Bonding Head Load #1',
                                          '有效导电粒子数量',
                                          'IC1_S_COUNT/FPC1_COUNT',
                                          'AOI结果',
                                          'NG Reason',
                                          h.testsubitemname) as testsubitemname,
                                   decode(teststation, 'POL贴附', s.controlupperlimit, h.controlupperLimit) as controlupperlimit,
                                   decode(teststation, 'POL贴附', s.controllowerlimit, h.controllowerLimit) as controllowerlimit,
                                   h.testunit,
                                   d.testresult
                              from g6_bem_hw_dcdata@dblk_edb d, ct_returninfo_hw h left join 
                                   (select a.productspecname,a.processoperationname,b.itemname,b.upperspeclimit as controlupperlimit,
                                           b.lowerspeclimit as controllowerlimit
                                      from spccontrolspec a, spccontrolspecitem b
                                     where a.spccontrolspecname = b.spccontrolspecname
                                       and b.itemname in ('CF_Ax','CF_Bx','CF_Cx','CF_Cy','CF_Dx','CF_Dy',
                                                  'TFT_Ax','TFT_Bx','TFT_Cx','TFT_Cy','TFT_Dx','TFT_Dy')) s 
                                   on 1=1 and (s.productspecname = h.productspec2name or s.productspecname = h.productspecname)
                                   and s.itemname = h.testsubitemname
                             where d.updatetime between
                                   to_date(:starttime, 'yyyy/mm/dd hh24:mi:ss') and
                                   to_date(:endtime, 'yyyy/mm/dd hh24:mi:ss')
                               and (d.productnumber = h.productspec2name or
                                   d.productnumber = h.productspecname)
                               and d.testsubitemname = decode(h.testitemName,
                                                              'Bonding 时间',
                                                              'Bonding Time #1',
                                                              'Bonding 温度',
                                                              'Bonding Backup Stage Temperature #1',
                                                              'Bonding 压力',
                                                              'Bonding Head Load #1',
                                                              '有效导电粒子数量',
                                                              'IC1_S_COUNT/FPC1_COUNT',
                                                              'AOI结果',
                                                              'NG Reason',
                                                              h.testsubitemname)";

            OracleCommand cmd = new OracleCommand();
            cmd.CommandText = ssql;

            cmd.Parameters.Add(new OracleParameter("starttime", starttime));
            cmd.Parameters.Add(new OracleParameter("endtime", endtime));

            DataSet ds = ora.GetDataSet(cmd);

            return ds;
        }

        private DataSet GetCustomQueryDetail1(OracleHelpMes ora, string starttime, string endtime)
        {
            string ssql = @"select d.customernumber,
                                   d.suppliername,
                                   d.factoryname,
                                   d.customermodel,
                                   d.lotnumber,
                                   d.serialnumber,
                                   d.productnumber,
                                   d.line,
                                   d.qctime,
                                   d.teststation,
                                   d.testitemname,
                                   d.testsubitemname,
                                   to_char((d.controlupperlimit + decode(substr(d.testitemname,4,5),'压力',11,'温度',12,'时间','5','0'))) as controlupperlimit,
                                   to_char((d.controllowerlimit + decode(substr(d.testitemname,4,5),'压力',11,'温度',12,'时间','5','0'))) as controllowerlimit,
                                   d.testunit,
                                   to_char((d.testresult + decode(substr(d.testitemname,4,5),'压力',11,'温度',12,'时间','5','0'))) as testresult,
                                   d.rawdataid,
                                   d.testcharresult,
                                   d.isverification,
                                   d.remark
                              from g6_bem_hw_dcdata@dblk_edb d
                             where d.timekey between :starttime and :endtime
                               and d.teststation = 'CFOG Bonding'
                            union
                            select d.customernumber,
                                   d.suppliername,
                                   d.factoryname,
                                   d.customermodel,
                                   d.lotnumber,
                                   d.serialnumber,
                                   d.productnumber,
                                   d.line,
                                   d.qctime,
                                   d.teststation,
                                   d.testitemname,
                                   d.testsubitemname,
                                   d.controlupperlimit,
                                   d.controllowerlimit,
                                   d.testunit,
                                   d.testresult,
                                   d.rawdataid,
                                   d.testcharresult,
                                   d.isverification,
                                   d.remark
                              from g6_bem_hw_dcdata@dblk_edb d
                             where d.timekey between :starttime and :endtime
                               and d.teststation <> 'CFOG Bonding' ";

            OracleCommand cmd = new OracleCommand();
            cmd.CommandText = ssql;

            cmd.Parameters.Add(new OracleParameter("starttime", starttime));
            cmd.Parameters.Add(new OracleParameter("endtime", endtime));

            DataSet ds = ora.GetDataSet(cmd);

            return ds;
        }

        public string PostAsync(CustomSendHW csHW, string strURL)
        {
            string retStr = "";
            try
            {
                var body = new FormUrlEncodedContent(new Dictionary<string, string>
                {
                    { "serviceInterfaceCode",csHW.serviceInterfaceCode},
                    { "fromInterfaceCode", csHW.fromInterfaceCode},
                    { "toInterfaceCode", csHW.toInterfaceCode},
                    { "ouZone", csHW.ouZone},
                    { "factoryName", csHW.factoryName},
                    { "uuid", csHW.uuid},
                    { "requestTime", csHW.requestTime},
                    { "data", csHW.data},
                });

                var httpClient = new HttpClient();

                string response = "";
                for (int i = 0; i < 20; i++)
                {
                    var responseVar = httpClient.PostAsync(strURL, body).Result;
                    response = responseVar.Content.ReadAsStringAsync().Result;
                    JObject resposeJson = JObject.Parse(response);
                    retStr = resposeJson["successMsg"].ToString();
                    if (string.Equals(retStr, "success")) break;
                    else insertErrorMessage(response, csHW.data);
                    Thread.Sleep(1000);
                }
            }
            catch { }

            return retStr;

        }

        private void checkTime_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                if (this.checkTime.Checked)
                {
                    this.dTPick.Enabled = false;
                    v_Hour = string.Format("{0:HH}", this.dTPick);
                    v_Minute = string.Format("{0:mm}", this.dTPick);
                }
                else 
                {
                    this.dTPick.Enabled = true;
                    v_Hour = "";
                    v_Minute = "";
                }
            }
            catch { }
        }

        private void FormBase_SizeChanged(object sender, EventArgs e)
        {
            try
            {
                //判断是否选择的是最小化按钮
                if (WindowState == FormWindowState.Minimized)
                {
                    //隐藏任务栏区图标
                    this.ShowInTaskbar = false;
                    //图标显示在托盘区
                    notifyIcon1.Visible = true;
                }
            }
            catch { }
        }

        private void notifyIcon1_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            try
            {
                if (WindowState == FormWindowState.Minimized)
                {
                    //还原窗体显示    
                    WindowState = FormWindowState.Normal;
                    //激活窗体并给予它焦点
                    this.Activate();
                    //任务栏区显示图标
                    this.ShowInTaskbar = true;
                    //托盘区图标隐藏
                    notifyIcon1.Visible = false;
                }
                else if (WindowState == FormWindowState.Normal)
                {
                    MessageBox.Show("sadiu");
                }
            }
            catch { }
        }

        private void FormBase_FormClosing(object sender, FormClosingEventArgs e)
        {
            try
            {
                char flag = (char)MessageBox.Show("关闭该界面,自动传输功能将失效,请确认!", "SendMessageToCustom", MessageBoxButtons.YesNo, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button2);
                if (flag == (char)DialogResult.No)
                {
                    e.Cancel = true;
                }
            }
            catch { }
        }

        private void SendMessage(DateTime nowTime)
        {
            try
            {
                smartThreadPool = new SmartThreadPool(5000, 2, 1);

                string prod = ConfigurationManager.AppSettings["PROD"].ToString();

                string prodConnectStr = ConfigurationManager.ConnectionStrings[prod].ConnectionString.ToString();

                oraProdEnv = new OracleHelpMes();
                oraProdEnv.baseStr = prodConnectStr;

                string strURL = " http://172.18.2.33:33001/b2b/mes/huawei/tplcdQCVoList";

                //DateTime nowTime = DateTime.Now;
                string startStr = string.Format("{0:yyyy-MM-dd}", nowTime.AddDays(-1)) + " 08:30:00";
                string endStr = string.Format("{0:yyyy-MM-dd}", nowTime) + " 08:30:00";
                DateTime startTime = Convert.ToDateTime(startStr);
                DateTime endTime = Convert.ToDateTime(endStr);
                DateTime v_dateTime = startTime;
                string v_startTime = "";
                string v_endTime = "";

                while (v_dateTime < endTime)
                {
                    v_startTime = string.Format("{0:yyyyMMddHHmm}", v_dateTime) + "00";
                    v_dateTime = v_dateTime.AddMinutes(5);
                    v_endTime = string.Format("{0:yyyyMMddHHmm}", v_dateTime) + "00";

                    DataSet getCustomHWList = GetCustomQueryDetail1(oraProdEnv, v_startTime, v_endTime);

                    if (getCustomHWList.Tables[0].Rows.Count > 0)
                    {
                        List<CustomHW> lstCusHW = new List<CustomHW>();
                        int setCount = 0;

                        for (int i = 0; i < getCustomHWList.Tables[0].Rows.Count; i++)
                        {
                            //decimal controlupperlimit = 0;
                            //decimal controllowerlimit = 0;
                            //if (!string.IsNullOrEmpty(getCustomHWList.Tables[0].Rows[i]["controlupperlimit"].ToString()))
                            //{
                            //    controlupperlimit = Convert.ToDecimal(getCustomHWList.Tables[0].Rows[i]["controlupperlimit"].ToString());
                            //}
                            //if (!string.IsNullOrEmpty(getCustomHWList.Tables[0].Rows[i]["controllowerlimit"].ToString()))
                            //{
                            //    controllowerlimit = Convert.ToDecimal(getCustomHWList.Tables[0].Rows[i]["controllowerlimit"].ToString());
                            //}
                            
                            //设置参数
                            CustomHW chw = new CustomHW();
                            chw.customerNumber = getCustomHWList.Tables[0].Rows[i]["customernumber"].ToString();
                            chw.supplierName = "天马";//getCustomHWList.Tables[0].Rows[i]["suppliername"].ToString();
                            chw.factoryName = getCustomHWList.Tables[0].Rows[i]["factoryname"].ToString();
                            chw.customerModel = getCustomHWList.Tables[0].Rows[i]["customermodel"].ToString();
                            chw.lotNumber = "";
                            chw.serialNumber = getCustomHWList.Tables[0].Rows[i]["serialnumber"].ToString();
                            chw.productNumber = getCustomHWList.Tables[0].Rows[i]["productnumber"].ToString();
                            chw.line = getCustomHWList.Tables[0].Rows[i]["line"].ToString();
                            chw.qcTime = ConvertDataTimeToLong(Convert.ToDateTime(getCustomHWList.Tables[0].Rows[i]["qctime"].ToString()));
                            chw.testStation = getCustomHWList.Tables[0].Rows[i]["teststation"].ToString();
                            chw.testItemName = getCustomHWList.Tables[0].Rows[i]["testitemname"].ToString();
                            chw.testSubItemName = getCustomHWList.Tables[0].Rows[i]["testsubitemname"].ToString();
                            chw.controlUpperLimit = getCustomHWList.Tables[0].Rows[i]["controlupperlimit"] == null ? "" : getCustomHWList.Tables[0].Rows[i]["controlupperlimit"].ToString();
                            chw.controlLowerLimit = getCustomHWList.Tables[0].Rows[i]["controllowerlimit"] == null ? "" : getCustomHWList.Tables[0].Rows[i]["controllowerlimit"].ToString();
                            chw.testUnit = getCustomHWList.Tables[0].Rows[i]["testunit"].ToString();
                            chw.testResult = getCustomHWList.Tables[0].Rows[i]["testresult"].ToString();
                            chw.rawDataID = getCustomHWList.Tables[0].Rows[i]["rawdataid"].ToString();
                            chw.testCharResult = getCustomHWList.Tables[0].Rows[i]["testcharresult"].ToString();
                            chw.isVerification = "";
                            chw.remark = "";

                            lstCusHW.Add(chw);
                            //string jsonParas = JsonConvert.SerializeObject(lstCusHW);

                            //CustomSendHW csHW = new CustomSendHW();
                            //csHW.serviceInterfaceCode = "B2BHW0100";
                            //csHW.fromInterfaceCode = "B2BTMXMMES0100";
                            //csHW.toInterfaceCode = "B2BHWH0100";
                            //csHW.ouZone = "OU_TMXM";
                            //csHW.factoryName = "XM G6";
                            //csHW.uuid = "1617355496bb588e353e80147eea5f45";
                            //csHW.requestTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
                            //csHW.data = jsonParas;

                            //var body = new FormUrlEncodedContent(new Dictionary<string, string>
                            //{
                            //    { "serviceInterfaceCode",csHW.serviceInterfaceCode},
                            //    { "fromInterfaceCode", csHW.fromInterfaceCode},
                            //    { "toInterfaceCode", csHW.toInterfaceCode},
                            //    { "ouZone", csHW.ouZone},
                            //    { "factoryName", csHW.factoryName},
                            //    { "uuid", csHW.uuid},
                            //    { "requestTime", csHW.requestTime},
                            //    { "data", csHW.data},
                            //});

                            //var httpClient = new HttpClient();
                            //var responseVar = httpClient.PostAsync(strURL, body).Result;
                            //string result = responseVar.Content.ReadAsStringAsync().Result;
                            //JObject resposeJson = JObject.Parse(result);
                            //string retStr = resposeJson["successMsg"].ToString();
                            //lstCusHW.Clear();

                            setCount++;

                            if (setCount == 100)
                            {
                                string jsonPara_Temp = JsonConvert.SerializeObject(lstCusHW);

                                CustomSendHW csHW_Temp = new CustomSendHW();
                                csHW_Temp.serviceInterfaceCode = "B2BHW0100";
                                csHW_Temp.fromInterfaceCode = "B2BTMXMMES0100";
                                csHW_Temp.toInterfaceCode = "B2BHWH0100";
                                csHW_Temp.ouZone = "OU_TMXM";
                                csHW_Temp.factoryName = "XM G6";
                                csHW_Temp.uuid = "1617355496bb588e353e80147eea5f45";
                                csHW_Temp.requestTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
                                csHW_Temp.data = jsonPara_Temp;

                                Amib.Threading.IWorkItemResult<string> threadRet = smartThreadPool.QueueWorkItem(new Amib.Threading.Func<CustomSendHW, string, string>(PostAsync),
                                    csHW_Temp, strURL);

                                //if (!string.Equals(threadRet.Result, "success")) this.txtReturnData.Text += "\n" + threadRet.Result;

                                setCount = 0;
                                lstCusHW.Clear();
                            }
                        }

                        string jsonParas = JsonConvert.SerializeObject(lstCusHW);

                        CustomSendHW csHW = new CustomSendHW();
                        csHW.serviceInterfaceCode = "B2BHW0100";
                        csHW.fromInterfaceCode = "B2BTMXMMES0100";
                        csHW.toInterfaceCode = "B2BHWH0100";
                        csHW.ouZone = "OU_TMXM";
                        csHW.factoryName = "XM G6";
                        csHW.uuid = "1617355496bb588e353e80147eea5f45";
                        csHW.requestTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
                        csHW.data = jsonParas;

                        Amib.Threading.IWorkItemResult<string> threadRet1 = smartThreadPool.QueueWorkItem(new Amib.Threading.Func<CustomSendHW, string, string>(PostAsync),
                                    csHW, strURL);

                        //if (!string.Equals(threadRet1.Result, "success")) this.txtReturnData.Text += "\n" + threadRet1.Result;
                    }

                    smartThreadPool.Start();
                    smartThreadPool.WaitForIdle();
                }

            }
            catch
            { this.txtReturnData.AppendText("发送失败!"); }
        }

        private void calculateYield(DateTime nowTime)
        {
            string startTime = string.Format("{0:yyyyMMdd}", nowTime.AddDays(-1)) + "083000";
            string endTime = string.Format("{0:yyyyMMdd}", nowTime) + "083000";

            string ssql = @"insert into ct_returninfo_yield_c
                              select s.timekey,
                                     s.productspec2name,
                                     s.productspecname,
                                     s.itemname,
                                     s.factoryname,
                                     trim(to_char(trunc(s.resultrate,2),90.99)) as resultrate,
                                     s.passqty,
                                     s.totalqty,
                                     s.duedate,
                                     y.resultrate as yield,
                                     (case
                                       when s.resultrate >= y.resultrate then
                                        'OK'
                                       else
                                        'NG'
                                     end) resultflag,
                                     'N' updatefalg
                                from (select d.productspec2name,
                                             d.productspecname,
                                             d.itemname,
                                             d.factoryname,
                                             sum(d.passqty) as passqty,
                                             sum(d.totalqty) as totalqty,
                                             sum(d.passqty) / sum(d.totalqty) as resultrate,
                                             to_char(sysdate, 'yyyymmddhh24miss') as timekey,
                                             to_char(sysdate - 1, 'yyyymmdd') as duedate
                                        from g6_bem_hw_dcdata_total@dblk_edb d
                                       where d.starttimekey >= :starttime
                                         and d.endtimekey < :endtime
                                       group by d.productspec2name,
                                                d.productspecname,
                                                d.itemname,
                                                d.factoryname) s,
                                     ct_returninfo_yield y
                               where y.productspec2name = s.productspec2name
                                 and y.productspecname = s.productspecname
                                 and y.itemname = s.itemname
                                 and y.factoryname = s.factoryname";

            OracleCommand cmd = new OracleCommand();
            cmd.CommandText = ssql;

            cmd.Parameters.Add(new OracleParameter("starttime", startTime));
            cmd.Parameters.Add(new OracleParameter("endtime", endTime));

            string prod = ConfigurationManager.AppSettings["PROD"].ToString();
            string prodConnectStr = ConfigurationManager.ConnectionStrings[prod].ConnectionString.ToString();

            oraProdEnv = new OracleHelpMes();
            oraProdEnv.baseStr = prodConnectStr;

            oraProdEnv.QueryCmd(cmd);
        }

        private bool chkAutoSend(DateTime nowTime)
        {
            bool retFlag = true;
            string dueDate = string.Format("{0:yyyyMMdd}", nowTime.AddDays(-1));

            string ssql = @"select c.timekey,c.productspec2name,c.productspecname,c.itemname
                              from ct_returninfo_yield_c c
                             where c.duedate = :duedate
                               and c.updateflag = 'N'
                               and c.resultflag = 'NG'";

            OracleCommand cmd = new OracleCommand();
            cmd.CommandText = ssql;

            cmd.Parameters.Add(new OracleParameter("duedate", dueDate));

            string prod = ConfigurationManager.AppSettings["PROD"].ToString();
            string prodConnectStr = ConfigurationManager.ConnectionStrings[prod].ConnectionString.ToString();

            oraProdEnv = new OracleHelpMes();
            oraProdEnv.baseStr = prodConnectStr;

            DataSet ds = oraProdEnv.GetDataSet(cmd);

            if (ds.Tables[0].Rows.Count > 0)
            {
                retFlag = false;
            }

            return retFlag;
        }

        private bool chkSendFromMes(DateTime nowTime)
        {
            bool retFlag = false;
            string dueDate = string.Format("{0:yyyyMMdd}", nowTime.AddDays(-1));

            string ssql = @"select c.timekey,c.productspec2name,c.productspecname,c.itemname
                              from ct_returninfo_yield_c c
                             where c.duedate = :duedate
                               and c.updateflag = 'Y'";

            OracleCommand cmd = new OracleCommand();
            cmd.CommandText = ssql;

            cmd.Parameters.Add(new OracleParameter("duedate", dueDate));

            string prod = ConfigurationManager.AppSettings["PROD"].ToString();
            string prodConnectStr = ConfigurationManager.ConnectionStrings[prod].ConnectionString.ToString();

            oraProdEnv = new OracleHelpMes();
            oraProdEnv.baseStr = prodConnectStr;

            DataSet ds = oraProdEnv.GetDataSet(cmd);

            if (ds.Tables[0].Rows.Count > 0)
            {
                retFlag = true;

                //将updateflag更新成Y1
                ssql = @"update ct_returninfo_yield_c c
                            set c.updateflag = 'Y1' 
                          where c.duedate = :duedate";

                cmd.CommandText = ssql;
                oraProdEnv.QueryCmd(cmd);
            }

            return retFlag;
        }

        private void insertErrorMessage(string response,string data)
        {
            string ssql = @"insert into ct_returninfo_hw_err(timekey,errormessage,message)
                              values(:timekey,:errormessage,:message)";

            OracleCommand cmd = new OracleCommand();
            cmd.CommandText = ssql;

            cmd.Parameters.Add(new OracleParameter("timekey", string.Format("{0:yyyyMMddHHmmss}", System.DateTime.Now)));
            cmd.Parameters.Add(new OracleParameter("errormessage", response));
            cmd.Parameters.Add(new OracleParameter("message", data));

            string prod = ConfigurationManager.AppSettings["PROD"].ToString();
            string prodConnectStr = ConfigurationManager.ConnectionStrings[prod].ConnectionString.ToString();

            oraProdEnv = new OracleHelpMes();
            oraProdEnv.baseStr = prodConnectStr;

            oraProdEnv.QueryCmd(cmd);

        }

        private void btnTest_Click(object sender, EventArgs e)
        {
            try
            {
                smartThreadPool = new SmartThreadPool(5000, 2, 1);

                string prod = ConfigurationManager.AppSettings["PROD"].ToString();

                string prodConnectStr = ConfigurationManager.ConnectionStrings[prod].ConnectionString.ToString();

                oraProdEnv = new OracleHelpMes();
                oraProdEnv.baseStr = prodConnectStr;

                this.btnSend.Enabled = false;

                string strURL = " http://172.18.2.33:33001/b2b/mes/huawei/tplcdQCVoList";

                string ssql = @"select d.customernumber,
                                   d.suppliername,
                                   d.factoryname,
                                   d.customermodel,
                                   d.lotnumber,
                                   d.serialnumber,
                                   d.productnumber,
                                   d.line,
                                   d.qctime,
                                   d.teststation,
                                   d.testitemname,
                                   d.testsubitemname,
                                   to_char((d.controlupperlimit + decode(substr(d.testitemname,4,5),'压力',11,'温度',12,'时间','5','0'))) as controlupperlimit,
                                   to_char((d.controllowerlimit + decode(substr(d.testitemname,4,5),'压力',11,'温度',12,'时间','5','0'))) as controllowerlimit,
                                   d.testunit,
                                   to_char((d.testresult + decode(substr(d.testitemname,4,5),'压力',11,'温度',12,'时间','5','0'))) as testresult,
                                   d.rawdataid,
                                   d.testcharresult,
                                   d.isverification,
                                   '测试数据' as remark
                              from g6_bem_hw_dcdata@dblk_edb d
                             where d.timekey between '20180825172000' and '20180825172500'
                               and d.serialnumber in ('Y86PR5130107C')
                               and d.teststation = 'CFOG Bonding' 
                            union
                            select d.customernumber,
                                   d.suppliername,
                                   d.factoryname,
                                   d.customermodel,
                                   d.lotnumber,
                                   d.serialnumber,
                                   d.productnumber,
                                   d.line,
                                   d.qctime,
                                   d.teststation,
                                   d.testitemname,
                                   d.testsubitemname,
                                   d.controlupperlimit,
                                   d.controllowerlimit,
                                   d.testunit,
                                   d.testresult,
                                   d.rawdataid,
                                   d.testcharresult,
                                   d.isverification,
                                   '测试数据' as remark
                              from g6_bem_hw_dcdata@dblk_edb d
                             where d.timekey between '20180825172000' and '20180825172500'
                               and d.serialnumber in ('Y86PR5130107C')
                               and d.teststation <> 'CFOG Bonding' ";

                OracleCommand cmd = new OracleCommand();
                cmd.CommandText = ssql;

                DataSet getCustomHWList = oraProdEnv.GetDataSet(cmd);

                if (getCustomHWList.Tables[0].Rows.Count > 0)
                {
                    List<CustomHW> lstCusHW = new List<CustomHW>();
                    int setCount = 0;

                    for (int i = 0; i < getCustomHWList.Tables[0].Rows.Count; i++)
                    {
                        //string controlupperlimit = "";
                        //string controllowerlimit = "";
                        //if (!string.IsNullOrEmpty(getCustomHWList.Tables[0].Rows[i]["controlupperlimit"].ToString()))
                        //{
                        //    controlupperlimit = Convert.ToDecimal(getCustomHWList.Tables[0].Rows[i]["controlupperlimit"].ToString());
                        //}
                        //if (!string.IsNullOrEmpty(getCustomHWList.Tables[0].Rows[i]["controllowerlimit"].ToString()))
                        //{
                        //    controllowerlimit = Convert.ToDecimal(getCustomHWList.Tables[0].Rows[i]["controllowerlimit"].ToString());
                        //}

                        //设置参数
                        CustomHW chw = new CustomHW();
                        chw.customerNumber = getCustomHWList.Tables[0].Rows[i]["customernumber"].ToString();
                        chw.supplierName = "天马"; // getCustomHWList.Tables[0].Rows[i]["suppliername"].ToString();
                        chw.factoryName = getCustomHWList.Tables[0].Rows[i]["factoryname"].ToString();
                        chw.customerModel = getCustomHWList.Tables[0].Rows[i]["customermodel"].ToString();
                        chw.lotNumber = "";
                        chw.serialNumber = getCustomHWList.Tables[0].Rows[i]["serialnumber"].ToString();
                        chw.productNumber = getCustomHWList.Tables[0].Rows[i]["productnumber"].ToString();
                        chw.line = getCustomHWList.Tables[0].Rows[i]["line"].ToString();
                        chw.qcTime = ConvertDataTimeToLong(Convert.ToDateTime(getCustomHWList.Tables[0].Rows[i]["qctime"].ToString()));
                        chw.testStation = getCustomHWList.Tables[0].Rows[i]["teststation"].ToString();
                        chw.testItemName = getCustomHWList.Tables[0].Rows[i]["testitemname"].ToString();
                        chw.testSubItemName = getCustomHWList.Tables[0].Rows[i]["testsubitemname"].ToString();
                        chw.controlUpperLimit = getCustomHWList.Tables[0].Rows[i]["controlupperlimit"] == null ? "" : getCustomHWList.Tables[0].Rows[i]["controlupperlimit"].ToString();
                        chw.controlLowerLimit = getCustomHWList.Tables[0].Rows[i]["controllowerlimit"] == null ? "" : getCustomHWList.Tables[0].Rows[i]["controllowerlimit"].ToString();
                        chw.testUnit = getCustomHWList.Tables[0].Rows[i]["testunit"].ToString();
                        chw.testResult = getCustomHWList.Tables[0].Rows[i]["testresult"].ToString();
                        chw.rawDataID = getCustomHWList.Tables[0].Rows[i]["rawdataid"].ToString();
                        chw.testCharResult = getCustomHWList.Tables[0].Rows[i]["testcharresult"].ToString();
                        chw.isVerification = "";
                        chw.remark = "测试数据";

                        lstCusHW.Add(chw);
                        setCount++;

                        if (setCount == 100)
                        {
                            string jsonPara_Temp = JsonConvert.SerializeObject(lstCusHW);

                            CustomSendHW csHW_Temp = new CustomSendHW();
                            csHW_Temp.serviceInterfaceCode = "B2BHW0100";
                            csHW_Temp.fromInterfaceCode = "B2BTMXMMES0100";
                            csHW_Temp.toInterfaceCode = "B2BHWH0100";
                            csHW_Temp.ouZone = "OU_TMXM";
                            csHW_Temp.factoryName = "XM G6";
                            csHW_Temp.uuid = "1617355496bb588e353e80147eea5f45";
                            csHW_Temp.requestTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
                            csHW_Temp.data = jsonPara_Temp;

                            Amib.Threading.IWorkItemResult<string> threadRet = smartThreadPool.QueueWorkItem(new Amib.Threading.Func<CustomSendHW, string, string>(PostAsync),
                                csHW_Temp, strURL);

                            setCount = 0;
                            lstCusHW.Clear();
                        }
                    }

                    string jsonParas = JsonConvert.SerializeObject(lstCusHW);

                    CustomSendHW csHW = new CustomSendHW();
                    csHW.serviceInterfaceCode = "B2BHW0100";
                    csHW.fromInterfaceCode = "B2BTMXMMES0100";
                    csHW.toInterfaceCode = "B2BHWH0100";
                    csHW.ouZone = "OU_TMXM";
                    csHW.factoryName = "XM G6";
                    csHW.uuid = "1617355496bb588e353e80147eea5f45";
                    csHW.requestTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
                    csHW.data = jsonParas;

                    Amib.Threading.IWorkItemResult<string> threadRet1 = smartThreadPool.QueueWorkItem(new Amib.Threading.Func<CustomSendHW, string, string>(PostAsync),
                                csHW, strURL);
                }

                smartThreadPool.Start();
                smartThreadPool.WaitForIdle();

            }
            catch { }
        }

        public long ConvertDataTimeToLong(DateTime dt)
        {
            DateTime dtStart = TimeZone.CurrentTimeZone.ToLocalTime(new DateTime(1970, 1, 1));
            TimeSpan toNow = dt.Subtract(dtStart);
            long timeStamp = toNow.Ticks;
            timeStamp = long.Parse(timeStamp.ToString().Substring(0, timeStamp.ToString().Length - 4));
            return timeStamp;
        }

    }
}