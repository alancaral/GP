﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using Newtonsoft.Json;
using System.Configuration;
using System.Net.Http;
using System.Data;
using Oracle.DataAccess.Client;
using System.ComponentModel;
using Amib.Threading;
using Newtonsoft.Json.Linq;
using System.Threading;

namespace HWTestData
{
    public partial class FormBase : Form
    {
        OracleHelpMes oraProdEnv;
        private static SmartThreadPool smartThreadPool;
        string v_Hour = "";
        string v_Minute = "";

        public FormBase()
        {
            InitializeComponent();
        }

        private void FormBase_Load(object sender, EventArgs e)
        {
            this.textBox1.ShortcutsEnabled = false;
            this.checkTime.Enabled = false;
            //this.btnSend.Enabled = false;
            System.Timers.Timer timer = new System.Timers.Timer();
            timer.Enabled = true;
            timer.Interval = 60000;//执行间隔时间,单位为毫秒  
            timer.Start();
            timer.Elapsed += new System.Timers.ElapsedEventHandler(Timer1_Elapsed); 
        }

        private void Timer1_Elapsed(object sender, System.Timers.ElapsedEventArgs e)  
        {
            string date = e.SignalTime.Date.ToShortDateString();

            //得到 hour minute second 如果等于某个值就开始执行某个程序。  
            string intHour = e.SignalTime.Hour.ToString();
            string intMinute = e.SignalTime.Minute.ToString();

            // 定制时间;比如在09:30:00的时候执行统计良率  
            string iHour = "13";
            string iMinute = "50";

            // 设置每天定时开始执行程序  
            if (intHour == iHour && intMinute == iMinute)
            {
                //发送前一天的数据
                SendMessage(e.SignalTime.Date);
            }

        }

        private void btnSend_Click(object sender, EventArgs e)
        {
            try
            {
                if ((char)MessageBox.Show("是否要手动发送数据,请确认!", "SendMessageToCustom", MessageBoxButtons.YesNo, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button2) == (char)DialogResult.No)
                {
                    return;
                }
            }
            catch { }
            finally
            {
                this.btnSend.Enabled = true;
            }
        }

        public string PostAsync(CustomSendHW csHW, string strURL)
        {
            string retStr = "";
            try
            {
                var body = new FormUrlEncodedContent(new Dictionary<string, string>
                {
                    { "serviceInterfaceCode",csHW.serviceInterfaceCode},
                    { "fromInterfaceCode", csHW.fromInterfaceCode},
                    { "toInterfaceCode", csHW.toInterfaceCode},
                    { "ouZone", csHW.ouZone},
                    { "factoryName", csHW.factoryName},
                    { "uuid", csHW.uuid},
                    { "requestTime", csHW.requestTime},
                    { "data", csHW.data},
                });

                var httpClient = new HttpClient();

                string response = "";
                for (int i = 0; i < 20; i++)
                {
                    var responseVar = httpClient.PostAsync(strURL, body).Result;
                    response = responseVar.Content.ReadAsStringAsync().Result;
                    JObject resposeJson = JObject.Parse(response);
                    retStr = resposeJson["successMsg"].ToString();
                    if (string.Equals(retStr, "success")) break;
                    else insertErrorMessage(response, csHW.data);
                    Thread.Sleep(1000);
                }
            }
            catch { }

            return retStr;

        }

        private void FormBase_SizeChanged(object sender, EventArgs e)
        {
            try
            {
                //判断是否选择的是最小化按钮
                if (WindowState == FormWindowState.Minimized)
                {
                    //隐藏任务栏区图标
                    this.ShowInTaskbar = false;
                    //图标显示在托盘区
                    notifyIcon1.Visible = true;
                }
            }
            catch { }
        }

        private void notifyIcon1_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            try
            {
                if (WindowState == FormWindowState.Minimized)
                {
                    //还原窗体显示    
                    WindowState = FormWindowState.Normal;
                    //激活窗体并给予它焦点
                    this.Activate();
                    //任务栏区显示图标
                    this.ShowInTaskbar = true;
                    //托盘区图标隐藏
                    notifyIcon1.Visible = false;
                }
                else if (WindowState == FormWindowState.Normal)
                {
                    MessageBox.Show("sadiu");
                }
            }
            catch { }
        }

        private void FormBase_FormClosing(object sender, FormClosingEventArgs e)
        {
            try
            {
                char flag = (char)MessageBox.Show("关闭该界面,自动传输功能将失效,请确认!", "SendMessageToCustom", MessageBoxButtons.YesNo, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button2);
                if (flag == (char)DialogResult.No)
                {
                    e.Cancel = true;
                }
            }
            catch { }
        }

        private void btnTest_Click(object sender, EventArgs e)
        {
            try
            {
                smartThreadPool = new SmartThreadPool(5000, 2, 1);

                string prod = ConfigurationManager.AppSettings["PROD"].ToString();

                string prodConnectStr = ConfigurationManager.ConnectionStrings[prod].ConnectionString.ToString();

                oraProdEnv = new OracleHelpMes();
                oraProdEnv.baseStr = prodConnectStr;

                this.btnSend.Enabled = false;

                string strURL = "http://10.100.8.234:33001/b2b/mes/huawei/tplcdQCVoList"; //B2B测试环境接口
                //string strURL = "http://172.18.2.33:33001/b2b/mes/huawei/tplcdQCVoList";  //B2B正式环境接口

                string ssql = @"select '23020603' as customernumber,
                                       '天马' as suppliername,
                                       'XM G6' as factoryname,
                                       'Paris' as customermodel,
                                       f.sn as lotnumber,
                                       f.sn as serialnumber,
                                       l.productspecname as productnumber,
                                       decode(f.machinename,'9205-01','9205-MXX-K1650003',f.machinename) as line,
                                       to_char(to_date(f.fromtime,'YYYY-MM-DD HH24:MI:SS'),'yyyy-mm-dd hh24:mi:ss') as qctime,
                                       'OQC' as teststation,
                                       '悍马-9205' as testitemname,
                                       f.testsubitemname as testsubitemname,
                                       '' as controlupperlimit,
                                       '' as controllowerlimit,
                                       '/' as testunit,
                                       f.testresult as testresult,
                                       '23020603_天马_XM G6_'||l.productspecname||'_'||decode(f.machinename,'9205-01','9205-MXX-K1650003',f.machinename)
                                       ||'_'||to_char(to_date(f.fromtime,'YYYY-MM-DD HH24:MI:SS'),'yyyymmddhh24miss') as rawdataid,
                                       f.result as testcharresult,
                                       '' as isverification,
                                       f.remark as remark
                                  from lstx_item_info f,lot@p2bem  l
                                 where f.itemtimekey between '20190122000000' and '20190123000000'
                                   and f.sn in ('Y8BPG63252079','Y8BPR3507306B')
                                   and f.sn = l.lotname ";

                OracleCommand cmd = new OracleCommand();
                cmd.CommandText = ssql;

                DataSet getCustomHWList = oraProdEnv.GetDataSet(cmd);

                if (getCustomHWList.Tables[0].Rows.Count > 0)
                {
                    List<CustomHW> lstCusHW = new List<CustomHW>();
                    int setCount = 0;

                    for (int i = 0; i < getCustomHWList.Tables[0].Rows.Count; i++)
                    {
                        //设置参数
                        CustomHW chw = new CustomHW();
                        chw.customerNumber = getCustomHWList.Tables[0].Rows[i]["customernumber"].ToString();
                        chw.supplierName = getCustomHWList.Tables[0].Rows[i]["suppliername"].ToString();
                        chw.factoryName = getCustomHWList.Tables[0].Rows[i]["factoryname"].ToString();
                        chw.customerModel = getCustomHWList.Tables[0].Rows[i]["customermodel"].ToString();
                        chw.lotNumber = getCustomHWList.Tables[0].Rows[i]["lotnumber"].ToString();
                        chw.serialNumber = getCustomHWList.Tables[0].Rows[i]["serialnumber"].ToString();
                        chw.productNumber = getCustomHWList.Tables[0].Rows[i]["productnumber"].ToString();
                        chw.line = getCustomHWList.Tables[0].Rows[i]["line"].ToString();
                        chw.qcTime = ConvertDataTimeToLong(Convert.ToDateTime(getCustomHWList.Tables[0].Rows[i]["qctime"].ToString()));
                        chw.testStation = getCustomHWList.Tables[0].Rows[i]["teststation"].ToString();
                        chw.testItemName = getCustomHWList.Tables[0].Rows[i]["testitemname"].ToString();
                        chw.testSubItemName = getCustomHWList.Tables[0].Rows[i]["testsubitemname"].ToString();
                        chw.controlUpperLimit = getCustomHWList.Tables[0].Rows[i]["controlupperlimit"] == null ? "" : getCustomHWList.Tables[0].Rows[i]["controlupperlimit"].ToString();
                        chw.controlLowerLimit = getCustomHWList.Tables[0].Rows[i]["controllowerlimit"] == null ? "" : getCustomHWList.Tables[0].Rows[i]["controllowerlimit"].ToString();
                        chw.testUnit = getCustomHWList.Tables[0].Rows[i]["testunit"].ToString();
                        chw.testResult = getCustomHWList.Tables[0].Rows[i]["testresult"].ToString();
                        chw.rawDataID = getCustomHWList.Tables[0].Rows[i]["rawdataid"].ToString();
                        chw.testCharResult = getCustomHWList.Tables[0].Rows[i]["testcharresult"].ToString();
                        chw.isVerification = "";
                        chw.remark = getCustomHWList.Tables[0].Rows[i]["remark"] == null ? "" : getCustomHWList.Tables[0].Rows[i]["remark"].ToString();

                        lstCusHW.Add(chw);
                        setCount++;

                        if (setCount == 100)
                        {
                            string jsonPara_Temp = JsonConvert.SerializeObject(lstCusHW);

                            CustomSendHW csHW_Temp = new CustomSendHW();
                            csHW_Temp.serviceInterfaceCode = "B2BHW0100";
                            csHW_Temp.fromInterfaceCode = "B2BTMXMMES0100";
                            csHW_Temp.toInterfaceCode = "B2BHWH0100";
                            csHW_Temp.ouZone = "OU_TMXM";
                            csHW_Temp.factoryName = "XM G6";
                            csHW_Temp.uuid = "1617355496bb588e353e80147eea5f45";
                            csHW_Temp.requestTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
                            csHW_Temp.data = jsonPara_Temp;

                            Amib.Threading.IWorkItemResult<string> threadRet = smartThreadPool.QueueWorkItem(new Amib.Threading.Func<CustomSendHW, string, string>(PostAsync),
                                csHW_Temp, strURL);

                            setCount = 0;
                            lstCusHW.Clear();
                        }
                    }

                    string jsonParas = JsonConvert.SerializeObject(lstCusHW);

                    CustomSendHW csHW = new CustomSendHW();
                    csHW.serviceInterfaceCode = "B2BHW0100";
                    csHW.fromInterfaceCode = "B2BTMXMMES0100";
                    csHW.toInterfaceCode = "B2BHWH0100";
                    csHW.ouZone = "OU_TMXM";
                    csHW.factoryName = "XM G6";
                    csHW.uuid = "1617355496bb588e353e80147eea5f45";
                    csHW.requestTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
                    csHW.data = jsonParas;

                    Amib.Threading.IWorkItemResult<string> threadRet1 = smartThreadPool.QueueWorkItem(new Amib.Threading.Func<CustomSendHW, string, string>(PostAsync),
                                csHW, strURL);
                }

                smartThreadPool.Start();
                smartThreadPool.WaitForIdle();

            }
            catch { }
        }

        public long ConvertDataTimeToLong(DateTime dt)
        {
            DateTime dtStart = TimeZone.CurrentTimeZone.ToLocalTime(new DateTime(1970, 1, 1));
            TimeSpan toNow = dt.Subtract(dtStart);
            long timeStamp = toNow.Ticks;
            timeStamp = long.Parse(timeStamp.ToString().Substring(0, timeStamp.ToString().Length - 4));
            return timeStamp;
        }

        private void insertErrorMessage(string response, string data)
        {
            string ssql = @"insert into ct_returninfo_hw_err(timekey,errormessage,message)
                              values(:timekey,:errormessage,:message)";

            OracleCommand cmd = new OracleCommand();
            cmd.CommandText = ssql;

            cmd.Parameters.Add(new OracleParameter("timekey", string.Format("{0:yyyyMMddHHmmss}", System.DateTime.Now)));
            cmd.Parameters.Add(new OracleParameter("errormessage", response));
            cmd.Parameters.Add(new OracleParameter("message", data));

            string prod = ConfigurationManager.AppSettings["PROD"].ToString();
            string prodConnectStr = ConfigurationManager.ConnectionStrings[prod].ConnectionString.ToString();

            oraProdEnv = new OracleHelpMes();
            oraProdEnv.baseStr = prodConnectStr;

            oraProdEnv.QueryCmd(cmd);

        }

        private void SendMessage(DateTime nowTime)
        {
            try
            {
                smartThreadPool = new SmartThreadPool(5000, 2, 1);

                string prod = ConfigurationManager.AppSettings["PROD"].ToString();

                string prodConnectStr = ConfigurationManager.ConnectionStrings[prod].ConnectionString.ToString();

                oraProdEnv = new OracleHelpMes();
                oraProdEnv.baseStr = prodConnectStr;

                string strURL = "http://10.100.8.234:33001/b2b/mes/huawei/tplcdQCVoList"; //B2B测试环境接口
                //string strURL = "http://172.18.2.33:33001/b2b/mes/huawei/tplcdQCVoList";  //B2B正式环境接口

                //DateTime nowTime = DateTime.Now;
                string startStr = string.Format("{0:yyyy-MM-dd}", nowTime.AddDays(-1)) + " 08:30:00";
                string endStr = string.Format("{0:yyyy-MM-dd}", nowTime) + " 08:30:00";
                DateTime startTime = Convert.ToDateTime(startStr);
                DateTime endTime = Convert.ToDateTime(endStr);
                DateTime v_dateTime = startTime;
                string v_startTime = "";
                string v_endTime = "";

                while (v_dateTime < endTime)
                {
                    v_startTime = string.Format("{0:yyyyMMddHHmm}", v_dateTime) + "00";
                    v_dateTime = v_dateTime.AddMinutes(1);
                    v_endTime = string.Format("{0:yyyyMMddHHmm}", v_dateTime) + "00";

                    DataSet getCustomHWList = GetCustomQueryDetail1(oraProdEnv, v_startTime, v_endTime);

                    if (getCustomHWList.Tables[0].Rows.Count > 0)
                    {
                        List<CustomHW> lstCusHW = new List<CustomHW>();
                        int setCount = 0;

                        for (int i = 0; i < getCustomHWList.Tables[0].Rows.Count; i++)
                        {
                            //设置参数
                            CustomHW chw = new CustomHW();
                            chw.customerNumber = getCustomHWList.Tables[0].Rows[i]["customernumber"].ToString();
                            chw.supplierName = "天马";//getCustomHWList.Tables[0].Rows[i]["suppliername"].ToString();
                            chw.factoryName = getCustomHWList.Tables[0].Rows[i]["factoryname"].ToString();
                            chw.customerModel = getCustomHWList.Tables[0].Rows[i]["customermodel"].ToString();
                            chw.lotNumber = getCustomHWList.Tables[0].Rows[i]["lotnumber"].ToString();
                            chw.serialNumber = getCustomHWList.Tables[0].Rows[i]["serialnumber"].ToString();
                            chw.productNumber = getCustomHWList.Tables[0].Rows[i]["productnumber"].ToString();
                            chw.line = getCustomHWList.Tables[0].Rows[i]["line"].ToString();
                            chw.qcTime = ConvertDataTimeToLong(Convert.ToDateTime(getCustomHWList.Tables[0].Rows[i]["qctime"].ToString()));
                            chw.testStation = getCustomHWList.Tables[0].Rows[i]["teststation"].ToString();
                            chw.testItemName = getCustomHWList.Tables[0].Rows[i]["testitemname"].ToString();
                            chw.testSubItemName = getCustomHWList.Tables[0].Rows[i]["testsubitemname"].ToString();
                            chw.controlUpperLimit = getCustomHWList.Tables[0].Rows[i]["controlupperlimit"] == null ? "" : getCustomHWList.Tables[0].Rows[i]["controlupperlimit"].ToString();
                            chw.controlLowerLimit = getCustomHWList.Tables[0].Rows[i]["controllowerlimit"] == null ? "" : getCustomHWList.Tables[0].Rows[i]["controllowerlimit"].ToString();
                            chw.testUnit = getCustomHWList.Tables[0].Rows[i]["testunit"].ToString();
                            chw.testResult = getCustomHWList.Tables[0].Rows[i]["testresult"].ToString();
                            chw.rawDataID = getCustomHWList.Tables[0].Rows[i]["rawdataid"].ToString();
                            chw.testCharResult = getCustomHWList.Tables[0].Rows[i]["testcharresult"].ToString();
                            chw.isVerification = "";
                            chw.remark = "";

                            lstCusHW.Add(chw);
                            setCount++;

                            if (setCount == 100)
                            {
                                string jsonPara_Temp = JsonConvert.SerializeObject(lstCusHW);

                                CustomSendHW csHW_Temp = new CustomSendHW();
                                csHW_Temp.serviceInterfaceCode = "B2BHW0100";
                                csHW_Temp.fromInterfaceCode = "B2BTMXMMES0100";
                                csHW_Temp.toInterfaceCode = "B2BHWH0100";
                                csHW_Temp.ouZone = "OU_TMXM";
                                csHW_Temp.factoryName = "XM G6";
                                csHW_Temp.uuid = "1617355496bb588e353e80147eea5f45";
                                csHW_Temp.requestTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
                                csHW_Temp.data = jsonPara_Temp;

                                Amib.Threading.IWorkItemResult<string> threadRet = smartThreadPool.QueueWorkItem(new Amib.Threading.Func<CustomSendHW, string, string>(PostAsync),
                                    csHW_Temp, strURL);

                                //if (!string.Equals(threadRet.Result, "success")) this.txtReturnData.Text += "\n" + threadRet.Result;

                                setCount = 0;
                                lstCusHW.Clear();
                            }
                        }

                        string jsonParas = JsonConvert.SerializeObject(lstCusHW);

                        CustomSendHW csHW = new CustomSendHW();
                        csHW.serviceInterfaceCode = "B2BHW0100";
                        csHW.fromInterfaceCode = "B2BTMXMMES0100";
                        csHW.toInterfaceCode = "B2BHWH0100";
                        csHW.ouZone = "OU_TMXM";
                        csHW.factoryName = "XM G6";
                        csHW.uuid = "1617355496bb588e353e80147eea5f45";
                        csHW.requestTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
                        csHW.data = jsonParas;

                        Amib.Threading.IWorkItemResult<string> threadRet1 = smartThreadPool.QueueWorkItem(new Amib.Threading.Func<CustomSendHW, string, string>(PostAsync),
                                    csHW, strURL);

                        //if (!string.Equals(threadRet1.Result, "success")) this.txtReturnData.Text += "\n" + threadRet1.Result;
                    }

                    smartThreadPool.Start();
                    smartThreadPool.WaitForIdle();
                }

            }
            catch
            { this.txtReturnData.AppendText("发送失败!"); }
        }

        private DataSet GetCustomQueryDetail1(OracleHelpMes ora, string starttime, string endtime)
        {
            string ssql = @"select p.customernumber,
                                   '天马' as suppliername,
                                   'XM G6' as factoryname,
                                   p.customermodel,
                                   f.sn as lotnumber,
                                   f.sn as serialnumber,
                                   l.productspecname as productnumber,
                                   f.machinename as line,
                                   to_char(to_date(f.fromtime,'YYYY-MM-DD HH24:MI:SS'),'yyyy-mm-dd hh24:mi:ss') as qctime,
                                   ('悍马-'||decode(f.machinename,'MXX-K1650006','9205','9515')) as teststation,
                                   f.testsubitemname as testitemname,
                                   '' as testsubitemname,
                                   f.usl as controlupperlimit,
                                   f.lsl as controllowerlimit,
                                   '/' as testunit,
                                   f.testresult as testresult,
                                   p.customernumber||'_天马_XM G6_'||p.customermodel||'_'||f.machinename
                                   ||'_'||to_char(to_date(f.fromtime,'YYYY-MM-DD HH24:MI:SS'),'yyyymmddhh24miss') as rawdataid,
                                   f.result as testcharresult,
                                   '' as isverification,
                                   f.remark as remark
                              from lstx_item_info f,lot@p2bem l,ct_returninfo_hw_pre p
                             where f.itemtimekey between :starttime and :endtime
                               and f.sn = l.lotname
                               and l.productspecname = p.productspecname
                               and f.testresult is not null ";

            OracleCommand cmd = new OracleCommand();
            cmd.CommandText = ssql;

            cmd.Parameters.Add(new OracleParameter("starttime", starttime));
            cmd.Parameters.Add(new OracleParameter("endtime", endtime));

            DataSet ds = ora.GetDataSet(cmd);

            return ds;
        }

    }
}