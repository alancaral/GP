﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HWTestData
{
    public class CustomSendHW
    {
        public string serviceInterfaceCode { get; set; }

        public string fromInterfaceCode { get; set; }

        public string toInterfaceCode { get; set; }

        public string ouZone { get; set; }
 
        public string factoryName { get; set; }

        public string uuid { get; set; }

        public string requestTime { get; set; }

        public string userName { get; set; }

        public string password { get; set; }

        public string sign { get; set; }

        public string data { get; set; }

    }
}
