﻿namespace HWPreData
{
    partial class FormBase
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormBase));
            this.btnSend = new System.Windows.Forms.Button();
            this.txtReturnData = new System.Windows.Forms.RichTextBox();
            this.dTPick = new System.Windows.Forms.DateTimePicker();
            this.时间设置 = new System.Windows.Forms.Label();
            this.checkTime = new System.Windows.Forms.CheckBox();
            this.NIPreData = new System.Windows.Forms.NotifyIcon(this.components);
            this.label1 = new System.Windows.Forms.Label();
            this.inputTime = new System.Windows.Forms.DateTimePicker();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.btnTest = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnSend
            // 
            this.btnSend.Location = new System.Drawing.Point(22, 271);
            this.btnSend.Name = "btnSend";
            this.btnSend.Size = new System.Drawing.Size(75, 23);
            this.btnSend.TabIndex = 5;
            this.btnSend.Text = "开始传输";
            this.btnSend.UseVisualStyleBackColor = true;
            this.btnSend.Click += new System.EventHandler(this.btnSend_Click);
            // 
            // txtReturnData
            // 
            this.txtReturnData.Location = new System.Drawing.Point(23, 53);
            this.txtReturnData.Name = "txtReturnData";
            this.txtReturnData.Size = new System.Drawing.Size(481, 153);
            this.txtReturnData.TabIndex = 25;
            this.txtReturnData.Text = "";
            // 
            // dTPick
            // 
            this.dTPick.CustomFormat = "HH:mm:ss";
            this.dTPick.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dTPick.Location = new System.Drawing.Point(140, 14);
            this.dTPick.Name = "dTPick";
            this.dTPick.Size = new System.Drawing.Size(108, 21);
            this.dTPick.TabIndex = 26;
            // 
            // 时间设置
            // 
            this.时间设置.Location = new System.Drawing.Point(22, 18);
            this.时间设置.Name = "时间设置";
            this.时间设置.Size = new System.Drawing.Size(114, 18);
            this.时间设置.TabIndex = 27;
            this.时间设置.Text = "固定发送时间点设置";
            // 
            // checkTime
            // 
            this.checkTime.AutoSize = true;
            this.checkTime.Location = new System.Drawing.Point(257, 19);
            this.checkTime.Name = "checkTime";
            this.checkTime.Size = new System.Drawing.Size(15, 14);
            this.checkTime.TabIndex = 28;
            this.checkTime.UseVisualStyleBackColor = true;
            // 
            // NIPreData
            // 
            this.NIPreData.Icon = ((System.Drawing.Icon)(resources.GetObject("NIPreData.Icon")));
            this.NIPreData.Text = "NIPreData";
            this.NIPreData.Visible = true;
            this.NIPreData.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.notifyIcon1_MouseDoubleClick);
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(22, 221);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(101, 18);
            this.label1.TabIndex = 29;
            this.label1.Text = "手动传输时间设置";
            // 
            // inputTime
            // 
            this.inputTime.CustomFormat = "yyyy年MM月dd日  HH:mm:ss";
            this.inputTime.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.inputTime.Location = new System.Drawing.Point(22, 242);
            this.inputTime.Name = "inputTime";
            this.inputTime.Size = new System.Drawing.Size(182, 21);
            this.inputTime.TabIndex = 30;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(306, 241);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 21);
            this.textBox1.TabIndex = 31;
            // 
            // btnTest
            // 
            this.btnTest.Location = new System.Drawing.Point(382, 12);
            this.btnTest.Name = "btnTest";
            this.btnTest.Size = new System.Drawing.Size(75, 23);
            this.btnTest.TabIndex = 32;
            this.btnTest.Text = "测试";
            this.btnTest.UseVisualStyleBackColor = true;
            this.btnTest.Click += new System.EventHandler(this.btnTest_Click);
            // 
            // FormBase
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(573, 307);
            this.Controls.Add(this.btnTest);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.inputTime);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.checkTime);
            this.Controls.Add(this.时间设置);
            this.Controls.Add(this.dTPick);
            this.Controls.Add(this.txtReturnData);
            this.Controls.Add(this.btnSend);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FormBase";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "HWPreData(正式环境)";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FormBase_FormClosing);
            this.Load += new System.EventHandler(this.FormBase_Load);
            this.SizeChanged += new System.EventHandler(this.FormBase_SizeChanged);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnSend;
        private System.Windows.Forms.RichTextBox txtReturnData;
        private System.Windows.Forms.DateTimePicker dTPick;
        private System.Windows.Forms.Label 时间设置;
        private System.Windows.Forms.CheckBox checkTime;
        private System.Windows.Forms.NotifyIcon NIPreData;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DateTimePicker inputTime;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button btnTest;
    }
}

