﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OracleClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Configuration;
using CustomHangle.Utils;


namespace CustomHangle
{
    public partial class Login : Form
    {
        OracleHelp oraProdEnv;
        public bool loginFlag = false;

        public Login()
        {
            InitializeComponent();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            try
            {
                string ssql = @"select u.*
                              from userprofile u
                             where u.userid = :userid";

                OracleCommand cmd = new OracleCommand();
                cmd.CommandText = ssql;

                cmd.Parameters.Add(new OracleParameter("userid", this.txtUser.Text));

                string dbname = ConfigurationManager.AppSettings["DBConnect"];
                string dbnameConnectStr = ConfigurationManager.ConnectionStrings[dbname].ConnectionString.ToString();

                oraProdEnv = new OracleHelp();
                oraProdEnv.baseStr = dbnameConnectStr;

                DataSet ds = oraProdEnv.GetDataSet(cmd);

                if (ds.Tables[0].Rows.Count > 0)
                {
                    loginFlag = true;
                    Form.ActiveForm.Close();
                }
                else
                {
                    loginFlag = false;
                }
            }
            catch { }
        }

        private void Login_Load(object sender, EventArgs e)
        {

        }
    }
}
