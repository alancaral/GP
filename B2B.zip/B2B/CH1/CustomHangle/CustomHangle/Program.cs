﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;

namespace CustomHangle
{
    static class Program
    {
        /// <summary>
        /// 应用程序的主入口点。
        /// </summary>
        [STAThread]
        static void Main()
        {
            System.Threading.Mutex mutexMyapplication = new System.Threading.Mutex(false, Application.ProductName + ".exe");
            if (!mutexMyapplication.WaitOne(100, false))
            {
                MessageBox.Show("程序" + Application.ProductName + "已经运行！", Application.ProductName,
                MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            log4net.Config.XmlConfigurator.Configure();

            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            //程序首先显示登陆界面
            Login login = new Login();
            login.StartPosition = FormStartPosition.CenterScreen;
            login.ShowDialog();
            //登陆结果正确之后显示主界面
            if (login.loginFlag)
            {
                login.Dispose();
                Application.Run(new formMain());
            }
            else if (login.DialogResult == DialogResult.Cancel)
            {
                login.Dispose();
                return;
            }
        }
    }
}
