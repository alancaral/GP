﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace CustomHangle
{
    public partial class formMain : Form
    {
        public formMain()
        {
            InitializeComponent();
        }

        private void formMain_Load(object sender, EventArgs e)
        {
           
        }

        private void formMain_FormClosing(object sender, FormClosingEventArgs e)
        {
            try
            {
                char flag = (char)MessageBox.Show("是否退出该系统!", "Warning", MessageBoxButtons.YesNo, MessageBoxIcon.Warning, MessageBoxDefaultButton.Button2);
                if (flag == (char)DialogResult.No)
                {
                    e.Cancel = true;
                }
            }
            catch { }
        }
    }
}
